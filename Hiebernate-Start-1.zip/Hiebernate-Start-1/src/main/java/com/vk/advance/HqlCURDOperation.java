package com.vk.advance;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HqlCURDOperation {

	public static void main(String[] args) {
		
	Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
    @SuppressWarnings("deprecation")
	SessionFactory sf = cfg.buildSessionFactory();
    Session session = sf.openSession();
    Transaction transaction = session.beginTransaction();
    
    Query q=session.createQuery("update Employee set employeeName='venkat' where employeeId=1 ");
     int i=q.executeUpdate();
     System.out.println(i);
     transaction.commit();
     session.close();
     sf.close();
}
}
